//
//  MyApp.swift
//  GradientDescend
//
//  Created by Ryan D on 4/5/22.
//

import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
